import java.util.Scanner;

class area{

	void circle(){
		double a;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the radius");
		double r=sc.nextDouble();
		a= Math.PI * (r * r);
		System.out.println("The area is "+a);

	}
	void triangle(){
		double ar;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the breadth");
		int b=sc.nextInt();
		System.out.println("enter the altitude");
		int h=sc.nextInt();
		ar=(b*h)/ 2;
		System.out.println("The area is" +ar);

	}
	public static void main(String args[]){
		area aa=new area();
		System.out.println("enter the choice");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		
			switch(n){
				case 1: System.out.println("circle");
				aa.circle();
				break;
				case 2: System.out.println("triangle");
				aa.triangle();
				break;
				default :System.out.println("The invalid  choice"); 
				break;

			}
		

		

	}
}