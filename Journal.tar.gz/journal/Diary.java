public class Diary extends JFrame implements ActionListener {


   private JTextArea textArea;
        private JButton Save, Date;

      public Diary() {
          super("Lab 8");

      
          JFrame frame = new JFrame("Calculator"); // creates the JFrame(a window with decorations)
          setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // stops the program when window is closed
          setSize(600, 600);
          setVisible(true);
          JPanel content = new JPanel(new GridLayout(6, 4));
          JPanel ButtonArea = new JPanel(new GridLayout(2, 2));

          textArea = new JTextArea();

          content.add(textArea);
          content.add(ButtonArea);
           Save = new JButton("Save");
           Date = new JButton("Date");
          add(textArea, BorderLayout.CENTER);
          add(ButtonArea, BorderLayout.SOUTH);
      
          ButtonArea.add(Save);
          ButtonArea.add(Date);
          Save.addActionListener((ActionListener) this);
          Date.addActionListener((ActionListener) this);
          try
            {
                    BufferedReader br = new BufferedReader(new FileReader("mydiary.txt"));
                      ArrayList results = new ArrayList();
                      String line = br.readLine();
                      while (line != null) {
                          results.add(line + "\n");
                          line = br.readLine();
                      }
                      String s = results.toString();
                   s = s.substring(1, s.length()-1);
                   s = s.replaceAll(",", "");
              
                       textArea.setText(s);
           br.close();
            } catch(FileNotFoundException e)
            {
                System.out.println("Cannot find file mydiary.txt.");
            }
           catch(IOException e)
            {
                System.out.println("Problems with input from mydiary.txt.");
            }
      }


   @Override
   public void actionPerformed(ActionEvent ae) {
       DateFormat df = new SimpleDateFormat("E MMM dd k:m:s z yyyy");
       Date today = Calendar.getInstance().getTime();      
       String reportDate = df.format(today);
           if(ae.getSource()==Save)
             
         
            try {
               PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("mydiary.txt", true)));
               out.println("\n" + reportDate);
               out.close();
            } catch (IOException e) {
                 System.out.println("Error in writing to file");
                }
           if(ae.getSource()==Date)
               try
           {
                       BufferedReader br = new BufferedReader(new FileReader("mydiary.txt"));
                         ArrayList results = new ArrayList();
                         String line = br.readLine();
                         while (line != null) {
                             results.add(line + "\n");
                             line = br.readLine();
                         }
                      String s = results.toString();
                  s = s.substring(1, s.length()-1);
                  s = s.replaceAll(",", "");

                             textArea.setText( s + reportDate);
              br.close();
            } catch(FileNotFoundException e)
            {
                System.out.println("Cannot find file mydiary.txt.");
            }
              catch(IOException e)
            {
                System.out.println("Problems with input from mydiary.txt.");
            }    
      
   }

  
      public static void main(String[] args) {

          SecondTest frame = new SecondTest();
            }
   }