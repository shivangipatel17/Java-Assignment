import java.util.Scanner;
class fact{
	public void factorial(){
		int f=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		for(int i=1;i<=n;i++){
			f=f*i;
			
		}
		System.out.println("The factorial of number is " +f);
	
	}
	public static void main(String args[]){
		fact fa=new fact();
		fa.factorial();
	}
}