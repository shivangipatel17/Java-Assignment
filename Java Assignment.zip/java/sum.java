import io.*;
class sum{
	public static void main(String[] args){
		int a,b,sum;
		BufferedReader br= new BufferedReader( new InputStreamReader(System.in));
		System.out.println("enter the value of a and b");
		a=Integer.parseInt(br.readLine());
        b=Integer.parseInt(br.readLine());
		sum = a + b;
System.out.println("the sum is:"+sum);	
}
}