import java.util.Scanner;
class count{
	void sample(){
		int count=0;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number of digits");
		int a=sc.nextInt();
		
		System.out.println("enter the digits");
		
		for(int i=0;i<a;i++){
			
			while(a<=7){
				count++;
				break;

			}
			System.out.println("\n"+count);
		}
		

	}
	public static void main(String args[]){
		count c=new count();
		c.sample();
	}
}