import java.util.Scanner;
public class switchi{
	public void cases(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of operations");
		int a=sc.nextInt();
		System.out.println("Enter the two numbers");
			int b=sc.nextInt();
			int c=sc.nextInt();
			int d;
          for(int i=0;i<a;i++){
          	switch(i){
			
			case 1 : 
			System.out.println("addition operation");
			 d=b+c;
			System.out.println("The sum is" +d);
			break;
			case 2 :
			System.out.println("substraction  operation");
			 d=b-c;
			System.out.println("The output is" +d);
			break;
			case 3 :
			System.out.println("multiplication  operation");
			 d=b*c;
			System.out.println("The output  is" +d);
			break;
			case 4:
			System.out.println("division  operation");
			 d=b/c;
			 System.out.println("The output  is" +d);
			break;
			case 5:
			System.out.println("division  operation");
			d=b%c;
			System.out.println("The output  is" +d);

			break;

			default : System.out.println("The invalid operation chosen"); 
			break;
		}

		}
          }

		
	
	public static void main (String args[]){
		switchi c=new  switchi();
		c.cases();
	}
}
