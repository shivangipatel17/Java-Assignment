import java.util.Scanner;
class sortt{