import java.util.Scanner;
public class dist{
	void distance()
	{
		double d,d1;
     Scanner sc=new Scanner(System.in);
     System.out.println("enter the point 1");
     float x1=sc.nextFloat();
     float y1=sc.nextFloat();
     System.out.println("enter the point 2");
     float x2=sc.nextFloat();
     float y2=sc.nextFloat();
     d=((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1));
      d1=Math.sqrt(d);
      System.out.println("The distance between two points" +d1);


	}
	public static void main(String args[])
	{
		dist dd=new dist();
		dd.distance();
	}
}