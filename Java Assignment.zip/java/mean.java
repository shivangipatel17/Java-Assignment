import java.util.Scanner;
class mean{
	void cal(){


	int sum=0;

		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the size of array");
		int a=sc.nextInt();
		int ar1[] = new int[a];
		 System.out.println("Enter elements");
 
      for (  int i = 0 ; i < a ; i++ )
         
            ar1[i] = sc.nextInt();
        for (  int i = 0 ; i < a ; i++ )
        	sum=sum+ar1[i];
         double mean=sum/a;
         System.out.println("mean of the elements is "+mean);


	}
	public static void main(String args[]){
    	mean m=new mean();
    	m.cal();
}
}