import java.util.Scanner;
class centre{
	void centroid(){
		float c1,c2,c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the x coordinates");
		int x1=sc.nextInt();
		int x2=sc.nextInt();
		int x3=sc.nextInt();
		System.out.println("enter the y coordinates");
		int y1=sc.nextInt();
		int y2=sc.nextInt();
		int y3=sc.nextInt();
		c1=x1+x2+x3/3;
		c2=y1+y2+y3/3;
		
		System.out.println("the centroid is "+c1+c2);


	}
	public static void main(String args[]){
		centre ce=new centre();
		ce.centroid();
	}

}
