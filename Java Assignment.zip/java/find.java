import java.util.Scanner;
class find{
	void xvalue(){
		double d,x,x1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the general terms");
		double b=sc.nextDouble();
		double a=sc.nextDouble();
		double c=sc.nextDouble();
		d=(b*b)-(4*a*c);
		x=(-b)+Math.sqrt(d)/2*a;
		x1=(-b)-Math.sqrt(d)/2*a;
		System.out.println("the value "+x+ " " +x1);
	}
	public static void main(String args[]){
		find f=new find();
		f.xvalue();

	}

}