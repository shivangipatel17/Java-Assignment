import java.util.Scanner;
public class add{
	public void sum(){
		int c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		   int a=sc.nextInt(); 
        System.out.println("enter fsecond number");
		      int b=sc.nextInt(); 
		c=a+b;
		System .out.println("sum is "+ c);


	}
	public static void main(String args[]){
		add s=new add();
		 s.sum();
	
	}
}