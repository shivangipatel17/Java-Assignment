import java.util.Scanner;
class sats{
	void work(){
		int sum=0;
		double sum1=0,avg=0,var=0;

		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of operations");
		int n=sc.nextInt();
		System.out.println("enter the size of array");
		int a=sc.nextInt();
		int ar1[] = new int[a];
		 System.out.println("Enter elements");
 
      for (  int i = 0 ; i < a ; i++ )
         
            ar1[i] = sc.nextInt();
         for(int j=0;j<n;j++){
          	switch(j){
			case 1 :
			System.out.println("average");
			for (  int i = 0 ; i < a ; i++ )
        	sum=sum+ar1[i];
             avg=(double)sum/a;
           System.out.println("average of the elements is "+avg);
			break;
			case 2 :
			System.out.println("variance");

			 for (  int i = 0 ; i < a ; i++ )
        	  sum1=sum1+ Math.pow((ar1[i] - avg), 2);
        	  var = sum / a;
        	
			System.out.println("The output  is" +var);
			break;
			case 3:
			 System.out.println("standard deviation");
			 double std_dev = Math.sqrt(var);
        	 System.out.println("The output  is" +std_dev);
			 break;
			 default : System.out.println("The invalid operation chosen"); 
			break;
		}
	}
}

public static void main(String args[]){
    	sats ss=new sats();
        ss.work();
}
}
