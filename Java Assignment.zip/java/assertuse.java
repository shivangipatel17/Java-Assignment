import java.util.Scanner;
class assertuse{
	void fun()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter value");
		int a=sc.nextInt();
		System.out.println("enter value");
		int b=sc.nextInt();
	    assert a==b:"the numbers are equal";
		/*System.out.println("OK");*/
	}
	public static void main(String args[]){
		assertuse a=new assertuse();
		a.fun();
	}
}