import java.util.Scanner;
class sortt{
	void perform(){
		int temp;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the size of array");
		int a=sc.nextInt();
		int ar1[] = new int[a];
		 System.out.println("Enter elements");
 
      for (  int i = 0 ; i < a ; i++ ){

      	ar1[i] = sc.nextInt();
      }
       for (int i = 0; i < a; i++) 

        for (int j = i + 1; j < a; j++) 

             if (ar1[i] > ar1[j]) 
              {
                    temp = ar1[i];
                    ar1[i] = ar1[j];
                    ar1[j] = temp;
                }
            
	     System.out.print("sorted Order is :");

        for (int i = 0; i < a - 1; i++) 

        {
            System.out.println(ar1[i]s);

        }

        System.out.println(ar1[a - 1]);

    }
    public static void main(String args[]){
    	sortt s=new sortt();
    	s.perform();
}


}
