import java.util.Scanner;
class sqr{
	void square(){
		int sq;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number to find its square");
		int a=sc.nextInt();
		sq=a*a;
		System.out.println("The sqaure is " +sq);
	}
	public static void main(String args[]){
		sqr s=new sqr();
		s.square();
	}
}