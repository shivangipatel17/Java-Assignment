import java.util.Scanner;
class addmatrix{
	void sum()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the row");
		int r=sc.nextInt();
		System.out.println("enter the column");
		int c=sc.nextInt();
		int ar1[][] = new int[r][c];
        int ar2[][] = new int[r][c];
        int sum[][] = new int[r][c];
       System.out.println("Enter the  first matrix");
 
      for (  int i = 0 ; i < r ; i++ )
         for ( int j = 0 ; j < c ; j++ )
            ar1[i][j] = sc.nextInt();
 
      System.out.println("Enter the second matrix");
 
      for (int i = 0 ; i < r ; i++ )
         for (int  j = 0 ; j < c ; j++ )
            ar2[i][j] = sc.nextInt();
 
      for ( int i = 0 ; i < r ; i++ )
         for ( int j = 0 ; j < c ; j++ )
             sum[i][j] = ar1[i][j] + ar2[i][j];  
      System.out.println("Sum of  matrices is");
 
      for ( int i = 0 ; i< r ; i++ )
      
         for ( int j = 0 ; j < c ; j++ )
            System.out.print(sum[i][j]+"\t");
 
         System.out.println();
      }


public static void main(String args[]){
    	addmatrix am=new addmatrix();
    	am.sum();

	}
}