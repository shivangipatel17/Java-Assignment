import java.util.Scanner;
class switch{
	public void cases(){
		Scannerb sc=new Scanner(System.in);
		System.out.println("enter the number of operations");
		int a=sc.nextInt();

		switch(a){
			System.out.println("Enter the two numbers");
			int b=sc.nextInt();
			int c=sc.nextInt();
			case 1 : 
			System.out.println("addition operation");
			int d=b+c;
			System.out.println("The sum is" +d);
			case 2 :
			System.out.println("substraction  operation");
			int d=b-c;
			System.out.println("The output is" +d);
			case 3 :
			System.out.println("multiplication  operation");
			int d=b*c;
			System.out.println("The output  is" +d);
			case 4:
			System.out.println("division  operation");
			int d=b/c;
			System.out.println("The output  is" +d);
			case 5:
			System.out.println("division  operation");
			int d=b%c;
			System.out.println("The output  is" +d);
			default : System.out.println("The invalid operation chosen"); 
			break;


		}
	}
	public static void main (String args[]){
		switch c=new  switch();
		c.cases();
	}
}
