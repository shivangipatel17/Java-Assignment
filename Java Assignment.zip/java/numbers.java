import java.util.Scanner;
class numbers{
	public void num(){
		Scanner sc=new Scanner(System.in);
		System.out.println("how many numbers u want to enter");
		int a=sc.nextInt();
		System.out.println("enter the numbers" );
		int max=sc.nextInt();
		for(int i=0;i<a;i++){
			int temp=sc.nextInt();
			if(temp<max){
				continue;
			}
			else{

				max=temp;


			} 


System.out.println("The largest number" +max);

		}
	}
	public static void main(String args[]){
		numbers n=new numbers();
		n.num();

	}
}